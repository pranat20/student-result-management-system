<?php include 'db.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SRMS — Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container my-5">
  <div class="row g-4">
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Departments</h5>
          <p class="card-text">Add and manage departments.</p>
          <a href="departments.php" class="btn btn-primary">Manage Departments</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Students</h5>
          <p class="card-text">Add / edit students department-wise.</p>
          <a href="students.php" class="btn btn-primary">Manage Students</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Subjects & Marks</h5>
          <p class="card-text">Subjects for departments and marks entry.</p>
          <a href="subjects.php" class="btn btn-primary">Subjects</a>
          <a href="marks.php" class="btn btn-outline-primary ms-2">Marks</a>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4 g-4">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Results</h5>
          <p class="card-text">Calculate and view results department-wise.</p>
          <a href="results.php" class="btn btn-success">View / Calculate Results</a>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Transcript</h5>
          <p class="card-text">View per-student subject-wise transcript.</p>
          <a href="transcript.php" class="btn btn-info">View Transcript</a>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
