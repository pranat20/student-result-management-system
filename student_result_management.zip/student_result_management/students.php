<?php
include 'db.php';
$success = $error = '';
// handle add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['student_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $roll_no = trim($_POST['roll_no'] ?? '');
    $dept = intval($_POST['department_id'] ?? 0);
    $year = intval($_POST['year'] ?? 1);

    if ($name==='' || $roll_no==='' || $dept<=0) $error="Fill all required fields.";
    else {
        if ($id>0) {
            $stmt = $conn->prepare("UPDATE students SET name=?, roll_no=?, department_id=?, year=? WHERE student_id=?");
            $stmt->bind_param('ssiii', $name, $roll_no, $dept, $year, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO students (name, roll_no, department_id, year) VALUES (?,?,?,?)");
            $stmt->bind_param('ssii', $name, $roll_no, $dept, $year);
        }
        try { $stmt->execute(); $success = $id>0 ? "Student updated." : "Student added."; }
        catch (mysqli_sql_exception $e) { if ($conn->errno===1062) $error="Roll number already exists in this department."; else $error=$e->getMessage(); }
        $stmt->close();
    }
}

// delete
if (isset($_GET['delete'])) {
    $del = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM students WHERE student_id=?");
    $stmt->bind_param('i', $del);
    if ($stmt->execute()) $success = "Student deleted.";
    $stmt->close();
}

// export csv
if (isset($_GET['export']) && $_GET['export']==='csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=students.csv');
    $out = fopen('php://output','w');
    fputcsv($out, ['student_id','name','roll_no','department_id','year','created_at']);
    $res = $conn->query("SELECT * FROM students ORDER BY name");
    while($r = $res->fetch_assoc()) fputcsv($out, $r);
    fclose($out); exit;
}

$departments = $conn->query("SELECT * FROM departments ORDER BY dept_name");
$students = $conn->query("SELECT s.*, d.dept_name FROM students s JOIN departments d ON s.department_id=d.department_id ORDER BY d.dept_name, s.name");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Students</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css"></head><body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Students</h3>
  <?php if($success):?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if($error):?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <form method="post" class="row g-2">
        <input type="hidden" name="student_id" id="student_id">
        <div class="col-md-4"><input class="form-control" id="name" name="name" placeholder="Full name" required></div>
        <div class="col-md-2"><input class="form-control" id="roll_no" name="roll_no" placeholder="Roll no" required></div>
        <div class="col-md-3">
          <select class="form-select" name="department_id" id="department_id" required>
            <option value="">Select Department</option>
            <?php while($d=$departments->fetch_assoc()): ?>
              <option value="<?= e($d['department_id']) ?>"><?= e($d['dept_name']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-2"><input type="number" class="form-control" id="year" name="year" min="1" max="6" value="1" required></div>
        <div class="col-md-1">
          <button class="btn btn-primary w-100" type="submit">Save</button>
        </div>
      </form>
    </div>
  </div>

  <div class="d-flex justify-content-between mb-2">
    <div></div>
    <div><a class="btn btn-outline-success" href="?export=csv">Export CSV</a></div>
  </div>

  <table class="table table-striped">
    <thead><tr><th>#</th><th>Name</th><th>Roll</th><th>Dept</th><th>Year</th><th>Actions</th></tr></thead>
    <tbody>
      <?php $i=1; while($s = $students->fetch_assoc()): ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= e($s['name']) ?></td>
          <td><?= e($s['roll_no']) ?></td>
          <td><?= e($s['dept_name']) ?></td>
          <td><?= e($s['year']) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-primary" onclick='editStudent(<?= json_encode($s) ?>)'>Edit</button>
            <a class="btn btn-sm btn-outline-danger" href="?delete=<?= e($s['student_id']) ?>" onclick="return confirm('Delete student?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <p><a class="link" href="index.php">Back</a></p>
</div>

<script>
function editStudent(obj) {
  document.getElementById('student_id').value = obj.student_id;
  document.getElementById('name').value = obj.name;
  document.getElementById('roll_no').value = obj.roll_no;
  document.getElementById('department_id').value = obj.department_id;
  document.getElementById('year').value = obj.year;
}
</script>
</body></html>
