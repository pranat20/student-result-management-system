<?php
include 'db.php';
$messages = [];
if (isset($_POST['calculate'])) {
    // calculate results for selected department or all
    $dept = intval($_POST['department_id'] ?? 0);
    $sql = "SELECT s.student_id, s.name,
            COALESCE(SUM(m.marks_obtained),0) AS total_obtained,
            COALESCE(SUM(sub.max_marks),0) AS total_max
            FROM students s
            LEFT JOIN marks m ON s.student_id = m.student_id
            LEFT JOIN subjects sub ON m.subject_id = sub.subject_id
            " . ($dept>0 ? " WHERE s.department_id = $dept " : "") .
            " GROUP BY s.student_id";
    $res = $conn->query($sql);
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $sid = intval($r['student_id']);
            $obt = intval($r['total_obtained']);
            $max = intval($r['total_max']);
            $perc = $max>0 ? round(($obt/$max)*100,2) : 0.00;
            if ($perc >= 90) $grade = 'A+'; elseif ($perc>=80) $grade='A'; elseif ($perc>=70) $grade='B'; elseif ($perc>=60) $grade='C'; elseif ($perc>=50) $grade='D'; else $grade='F';
            $stmt = $conn->prepare("INSERT INTO result (student_id, total_marks, total_max, percentage, grade) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE total_marks=VALUES(total_marks), total_max=VALUES(total_max), percentage=VALUES(percentage), grade=VALUES(grade), calculated_at=CURRENT_TIMESTAMP");
            $stmt->bind_param('iiids', $sid, $obt, $max, $perc, $grade);
            if ($stmt->execute()) $messages[] = "Updated result for {$r['name']}";
            else $messages[] = "Error for {$r['name']}: ".$stmt->error;
            $stmt->close();
        }
    } else $messages[] = "Calculation query failed: ".$conn->error;
}

// fetch departments & optionally results
$deps = $conn->query("SELECT * FROM departments ORDER BY dept_name");
$filter_dept = intval($_GET['department_id'] ?? 0);
$sql2 = "SELECT res.*, s.name, s.roll_no, d.dept_name FROM result res JOIN students s ON res.student_id=s.student_id JOIN departments d ON s.department_id=d.department_id" . ($filter_dept>0 ? " WHERE d.department_id=$filter_dept" : "") . " ORDER BY res.percentage DESC";
$results = $conn->query($sql2);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head>
<body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Results</h3>
  <?php foreach($messages as $m): ?><div class="alert alert-info"><?= e($m) ?></div><?php endforeach; ?>

  <form method="post" class="row g-2 align-items-center mb-3">
    <div class="col-md-4">
      <select name="department_id" class="form-select">
        <option value="0">All Departments</option>
        <?php while($d=$deps->fetch_assoc()): ?>
          <option value="<?= e($d['department_id']) ?>"><?= e($d['dept_name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2"><button class="btn btn-success" name="calculate">Calculate / Update Results</button></div>
    <div class="col-md-6 text-end">
      <a class="btn btn-outline-secondary" href="results.php">Refresh View</a>
    </div>
  </form>

  <div class="mb-2">
    <form method="get" class="d-flex gap-2">
      <select name="department_id" class="form-select w-auto">
        <option value="">Filter by Department</option>
        <?php
        // re-fetch departments for filter dropdown
        $deps2 = $conn->query("SELECT * FROM departments ORDER BY dept_name");
        while($d2 = $deps2->fetch_assoc()): ?>
          <option value="<?= e($d2['department_id']) ?>" <?= ($filter_dept==$d2['department_id'])?'selected':''; ?>><?= e($d2['dept_name']) ?></option>
        <?php endwhile; ?>
      </select>
      <button class="btn btn-outline-primary" type="submit">Filter</button>
    </form>
  </div>

  <table class="table table-striped">
    <thead><tr><th>#</th><th>Name</th><th>Roll</th><th>Dept</th><th>Total</th><th>Max</th><th>%</th><th>Grade</th><th>Transcript</th></tr></thead>
    <tbody>
      <?php $i=1; while($r = $results->fetch_assoc()): ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= e($r['name']) ?></td>
          <td><?= e($r['roll_no']) ?></td>
          <td><?= e($r['dept_name']) ?></td>
          <td><?= e($r['total_marks']) ?></td>
          <td><?= e($r['total_max']) ?></td>
          <td><?= e($r['percentage']) ?>%</td>
          <td><?= e($r['grade']) ?></td>
          <td><a href="transcript.php?student_id=<?= e($r['student_id']) ?>">View</a></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <p><a class="link" href="index.php">Back</a></p>
</div>
</body></html>
