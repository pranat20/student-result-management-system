<?php
include 'db.php';
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['department_id'] ?? 0);
    $name = trim($_POST['dept_name'] ?? '');
    if ($name === '') $error = "Department name required.";
    else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE departments SET dept_name=? WHERE department_id=?");
            $stmt->bind_param('si', $name, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO departments (dept_name) VALUES (?)");
            $stmt->bind_param('s', $name);
        }
        try { $stmt->execute(); $success = $id>0 ? "Updated." : "Added."; } 
        catch (mysqli_sql_exception $e) { if ($conn->errno===1062) $error="Department already exists."; else $error=$e->getMessage(); }
        $stmt->close();
    }
}

// delete
if (isset($_GET['delete'])) {
    $del = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM departments WHERE department_id=?");
    $stmt->bind_param('i', $del);
    if ($stmt->execute()) $success = "Department deleted (and related data removed).";
    $stmt->close();
}

$departments = $conn->query("SELECT * FROM departments ORDER BY dept_name");
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Departments</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css"></head>
<body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Departments</h3>
  <?php if($success):?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if($error):?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <form method="post" class="row g-2">
        <input type="hidden" name="department_id" id="department_id">
        <div class="col-md-8">
          <input class="form-control" name="dept_name" id="dept_name" placeholder="Department name (e.g., Computer Science)">
        </div>
        <div class="col-md-4">
          <button class="btn btn-primary" type="submit">Save Department</button>
          <button type="button" class="btn btn-secondary" onclick="clearForm()">Clear</button>
        </div>
      </form>
    </div>
  </div>

  <table class="table table-striped">
    <thead><tr><th>#</th><th>Name</th><th>Created</th><th>Actions</th></tr></thead>
    <tbody>
      <?php $i=1; while($d = $departments->fetch_assoc()): ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= e($d['dept_name']) ?></td>
          <td><?= e($d['created_at']) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-primary" onclick="editDept(<?= e($d['department_id']) ?>, '<?= e(addslashes($d['dept_name'])) ?>')">Edit</button>
            <a class="btn btn-sm btn-outline-danger" href="?delete=<?= e($d['department_id']) ?>" onclick="return confirm('Delete department? This removes students, subjects, marks related.')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <p><a class="link" href="index.php">Back to Dashboard</a></p>
</div>

<script>
function editDept(id, name){
  document.getElementById('department_id').value = id;
  document.getElementById('dept_name').value = name;
}
function clearForm(){
  document.getElementById('department_id').value = '';
  document.getElementById('dept_name').value = '';
}
</script>
</body></html>
