<?php
include 'db.php';
$students = $conn->query("SELECT s.student_id, s.name, s.roll_no, d.dept_name FROM students s JOIN departments d ON s.department_id=d.department_id ORDER BY d.dept_name, s.name");
$selected = intval($_GET['student_id'] ?? 0);
$marks = []; $total_obt=0; $total_max=0;
if ($selected) {
    $stmt = $conn->prepare("SELECT sub.subject_name, sub.max_marks, m.marks_obtained FROM subjects sub LEFT JOIN marks m ON sub.subject_id=m.subject_id AND m.student_id=? WHERE sub.department_id=(SELECT department_id FROM students WHERE student_id=?) ORDER BY sub.subject_name");
    $stmt->bind_param('ii',$selected,$selected);
    $stmt->execute();
    $res = $stmt->get_result();
    while($row = $res->fetch_assoc()){
        $marks[] = $row;
        $total_obt += intval($row['marks_obtained']);
        $total_max += intval($row['max_marks']);
    }
    $stmt->close();
    $percentage = $total_max>0 ? round(($total_obt/$total_max)*100,2) : 0;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Transcript</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head>
<body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Transcript</h3>
  <form method="get" class="mb-3">
    <div class="row g-2">
      <div class="col-md-6">
        <select name="student_id" class="form-select" onchange="this.form.submit()">
          <option value="">Select Student</option>
          <?php while($s = $students->fetch_assoc()): ?>
            <option value="<?= e($s['student_id']) ?>" <?= ($selected==$s['student_id'])?'selected':''; ?>><?= e($s['name'].' ('.$s['roll_no'].') - '. $s['dept_name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
  </form>

  <?php if ($selected): ?>
    <table class="table table-bordered">
      <thead><tr><th>Subject</th><th>Marks Obtained</th><th>Max Marks</th></tr></thead>
      <tbody>
        <?php foreach($marks as $m): ?>
          <tr>
            <td><?= e($m['subject_name']) ?></td>
            <td><?= $m['marks_obtained'] === null ? '-' : e($m['marks_obtained']) ?></td>
            <td><?= e($m['max_marks']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><th>Total</th><th><?= e($total_obt) ?></th><th><?= e($total_max) ?></th></tr>
        <tr><th>Percentage</th><th colspan="2"><?= $total_max>0 ? e($percentage).'%' : '-' ?></th></tr>
      </tfoot>
    </table>
    <p><a class="link" href="results.php">View Result Summary</a></p>
  <?php endif; ?>

  <p><a class="link" href="index.php">Back</a></p>
</div>
</body></html>
