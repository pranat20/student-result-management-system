<?php
include 'db.php';
$success = $error = '';

$departments = $conn->query("SELECT * FROM departments ORDER BY dept_name");

// handle form post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dept = intval($_POST['department_id'] ?? 0);
    $student = intval($_POST['student_id'] ?? 0);
    $subject = intval($_POST['subject_id'] ?? 0);
    $marks = isset($_POST['marks_obtained']) ? intval($_POST['marks_obtained']) : null;
    $action = $_POST['action'] ?? 'save';

    if ($dept<=0 || $student<=0 || $subject<=0) $error = "Select department, student and subject.";
    else {
        // fetch max marks
        $q = $conn->prepare("SELECT max_marks FROM subjects WHERE subject_id=?");
        $q->bind_param('i',$subject);
        $q->execute();
        $res = $q->get_result()->fetch_assoc();
        $q->close();
        $max = $res ? intval($res['max_marks']) : 0;

        if ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM marks WHERE student_id=? AND subject_id=?");
            $stmt->bind_param('ii',$student,$subject);
            if ($stmt->execute()) $success = "Marks deleted.";
            else $error = $stmt->error;
            $stmt->close();
        } else {
            if (!is_numeric($marks) || $marks < 0) $error = "Enter valid marks.";
            elseif ($max>0 && $marks > $max) $error = "Marks cannot exceed max ($max).";
            else {
                $stmt = $conn->prepare("INSERT INTO marks (student_id, subject_id, marks_obtained) VALUES (?,?,?) ON DUPLICATE KEY UPDATE marks_obtained=VALUES(marks_obtained)");
                $stmt->bind_param('iii',$student,$subject,$marks);
                if ($stmt->execute()) $success = "Marks saved/updated.";
                else $error = $stmt->error;
                $stmt->close();
            }
        }
    }
}

// If dept selected in GET, fetch students & subjects for that dept
$selected_dept = intval($_GET['department_id'] ?? 0);
$students = $subjects = [];
if ($selected_dept) {
    $students_res = $conn->prepare("SELECT student_id, name, roll_no FROM students WHERE department_id=? ORDER BY name");
    $students_res->bind_param('i',$selected_dept);
    $students_res->execute();
    $students = $students_res->get_result();
    $students_res->close();

    $subjects_res = $conn->prepare("SELECT subject_id, subject_name, max_marks FROM subjects WHERE department_id=? ORDER BY subject_name");
    $subjects_res->bind_param('i',$selected_dept);
    $subjects_res->execute();
    $subjects = $subjects_res->get_result();
    $subjects_res->close();
}

// If student & subject provided in GET, fetch current marks
$current_marks = null;
if (isset($_GET['student_id']) && isset($_GET['subject_id'])) {
    $sid = intval($_GET['student_id']); $subid = intval($_GET['subject_id']);
    $r = $conn->prepare("SELECT marks_obtained FROM marks WHERE student_id=? AND subject_id=?");
    $r->bind_param('ii',$sid,$subid);
    $r->execute();
    $cur = $r->get_result()->fetch_assoc();
    if ($cur) $current_marks = intval($cur['marks_obtained']);
    $r->close();
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Marks Entry</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head>
<body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Marks Entry</h3>
  <?php if($success):?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if($error):?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <form method="get" class="row g-2 mb-3">
    <div class="col-md-4">
      <select name="department_id" class="form-select" onchange="this.form.submit()" >
        <option value="">Select Department</option>
        <?php while($d = $departments->fetch_assoc()): ?>
          <option value="<?= e($d['department_id']) ?>" <?= $selected_dept==$d['department_id']?'selected':''; ?>><?= e($d['dept_name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
  </form>

  <?php if($selected_dept): ?>
    <form method="post" class="row g-2">
      <input type="hidden" name="department_id" value="<?= e($selected_dept) ?>">
      <div class="col-md-4">
        <select name="student_id" class="form-select" required onchange="updateUrlParams()">
          <option value="">Select Student</option>
          <?php while($s = $students->fetch_assoc()): ?>
            <option value="<?= e($s['student_id']) ?>" <?= (isset($_GET['student_id']) && $_GET['student_id']==$s['student_id'])?'selected':''; ?>><?= e($s['name'].' ('.$s['roll_no'].')') ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-4">
        <select name="subject_id" class="form-select" required onchange="updateUrlParams()">
          <option value="">Select Subject</option>
          <?php while($sub = $subjects->fetch_assoc()): ?>
            <option value="<?= e($sub['subject_id']) ?>" <?= (isset($_GET['subject_id']) && $_GET['subject_id']==$sub['subject_id'])?'selected':''; ?>>
              <?= e($sub['subject_name'].' (Max '.$sub['max_marks'].')') ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2">
        <input name="marks_obtained" type="number" class="form-control" placeholder="Marks" value="<?= $current_marks !== null ? e($current_marks) : '' ?>">
      </div>
      <div class="col-md-2 d-flex gap-2">
        <button class="btn btn-primary" type="submit" name="action" value="save">Save / Update</button>
        <button class="btn btn-danger" type="submit" name="action" value="delete" onclick="return confirm('Delete marks?')">Delete</button>
      </div>
    </form>
  <?php else: ?>
    <div class="alert alert-info">Select department to start entering marks.</div>
  <?php endif; ?>

  <p class="mt-3"><a class="link" href="index.php">Back</a></p>
  <p class="note">Tip: selecting Student and Subject and clicking Save will update existing marks (no duplicates).</p>
</div>

<script>
function updateUrlParams(){
  // submit form to include student_id & subject_id in GET for current marks display
  const form = document.querySelector('form[method="post"]');
  const dept = document.querySelector('input[name="department_id"]').value;
  const student = document.querySelector('select[name="student_id"]').value;
  const subject = document.querySelector('select[name="subject_id"]').value;
  let url = new URL(window.location.href);
  url.searchParams.set('department_id', dept);
  if (student) url.searchParams.set('student_id', student); else url.searchParams.delete('student_id');
  if (subject) url.searchParams.set('subject_id', subject); else url.searchParams.delete('subject_id');
  window.location = url.toString();
}
</script>
</body></html>
