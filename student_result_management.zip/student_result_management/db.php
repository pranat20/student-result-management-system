<?php
// db.php - central DB connection & helpers
$DB_HOST = '127.0.0.1:3307'; // change if needed
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'student_result';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

function e($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url");
    exit;
}
?>
