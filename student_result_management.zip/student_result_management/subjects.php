<?php
include 'db.php';
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['subject_id'] ?? 0);
    $name = trim($_POST['subject_name'] ?? '');
    $code = trim($_POST['subject_code'] ?? '');
    $dept = intval($_POST['department_id'] ?? 0);
    $max = intval($_POST['max_marks'] ?? 100);

    if ($name==='' || $code==='' || $dept<=0) $error="Fill required fields.";
    else {
        if ($id>0) {
            $stmt = $conn->prepare("UPDATE subjects SET subject_name=?, subject_code=?, department_id=?, max_marks=? WHERE subject_id=?");
            $stmt->bind_param('ssiii', $name, $code, $dept, $max, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO subjects (subject_name, subject_code, department_id, max_marks) VALUES (?,?,?,?)");
            $stmt->bind_param('ssii', $name, $code, $dept, $max);
        }
        try { $stmt->execute(); $success = $id>0 ? "Subject updated." : "Subject added."; }
        catch (mysqli_sql_exception $e) { if ($conn->errno===1062) $error="Subject code already exists in department."; else $error=$e->getMessage(); }
        $stmt->close();
    }
}
if (isset($_GET['delete'])) {
    $del = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM subjects WHERE subject_id=?");
    $stmt->bind_param('i', $del);
    if ($stmt->execute()) $success = "Subject deleted.";
    $stmt->close();
}

$departments = $conn->query("SELECT * FROM departments ORDER BY dept_name");
$subjects = $conn->query("SELECT sub.*, d.dept_name FROM subjects sub JOIN departments d ON sub.department_id=d.department_id ORDER BY d.dept_name, sub.subject_name");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Subjects</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head>
<body><?php include 'navbar.php'; ?>
<div class="container my-4">
  <h3>Subjects</h3>
  <?php if($success):?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if($error):?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <div class="card mb-3"><div class="card-body">
    <form method="post" class="row g-2">
      <input type="hidden" id="subject_id" name="subject_id">
      <div class="col-md-4"><input class="form-control" id="subject_name" name="subject_name" required placeholder="Subject Name"></div>
      <div class="col-md-2"><input class="form-control" id="subject_code" name="subject_code" required placeholder="Code (e.g., DBMS)"></div>
      <div class="col-md-3">
        <select class="form-select" id="department_id" name="department_id" required>
          <option value="">Department</option>
          <?php while($d=$departments->fetch_assoc()): ?>
            <option value="<?= e($d['department_id']) ?>"><?= e($d['dept_name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2"><input class="form-control" id="max_marks" name="max_marks" type="number" value="100" min="1"></div>
      <div class="col-md-1"><button class="btn btn-primary w-100" type="submit">Save</button></div>
    </form>
  </div></div>

  <table class="table table-striped">
    <thead><tr><th>#</th><th>Name</th><th>Code</th><th>Dept</th><th>Max</th><th>Actions</th></tr></thead>
    <tbody>
      <?php $i=1; while($s=$subjects->fetch_assoc()): ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= e($s['subject_name']) ?></td>
          <td><?= e($s['subject_code']) ?></td>
          <td><?= e($s['dept_name']) ?></td>
          <td><?= e($s['max_marks']) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-primary" onclick='editSubject(<?= json_encode($s) ?>)'>Edit</button>
            <a class="btn btn-sm btn-outline-danger" href="?delete=<?= e($s['subject_id']) ?>" onclick="return confirm('Delete subject?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <p><a class="link" href="index.php">Back</a></p>
</div>

<script>
function editSubject(obj){
  document.getElementById('subject_id').value = obj.subject_id;
  document.getElementById('subject_name').value = obj.subject_name;
  document.getElementById('subject_code').value = obj.subject_code;
  document.getElementById('department_id').value = obj.department_id;
  document.getElementById('max_marks').value = obj.max_marks;
}
</script>
</body></html>
